﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("{0, -15} {1, -15}", "Grading ID:", "K3222");
            System.Console.WriteLine("{0, -15} {1, -15}", "Hobbies:", "Building PCs and Video Games");
            System.Console.WriteLine("{0, -15} {1, -12}", "Favorite Book:", "Tower of God");
            System.Console.WriteLine("{0, -15} {1, -15}", "Favorite Movie:", "Spiderman: No Way Home");
        }
    }
}
